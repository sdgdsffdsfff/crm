﻿<div data-role="footer" data-position="fixed">
  	 <div data-role="controlgroup" data-type="horizontal">
	  <a href="./note.php?type=05" data-role="button">零售导航</a> 
	  <a href="./note.php?type=06" data-role="button">服务导航</a> 
	  <a href="./note.php?type=07" data-role="button">推荐导航</a> 
	  <a href="./note.php?type=08" data-role="button">跟进导航</a>     
	 </div> 
	 <h4>Copyright 2014 苏州旗云</h4>
  </div>
﻿ <div data-role="header" data-position="fixed">
<div data-role="controlgroup" data-type="horizontal" style="overflow:hidden">
  <a href="./note.php?type=01" data-role="button" >公司介绍</a>
  <a href="./note.php?type=02" data-role="button" >产品介绍</a>
  <a href="./note.php?type=03" data-role="button">产品分享</a>
  <a href="./note.php?type=04" data-role="button">事业分享</a> 
  <a href="./m.php?act=quit" data-role="button" data-inline="true">退出</a> 
</div>
  </div>

  <div id="color_choose" class="color_choose" onClick="javascript:mysub();"></div>
    <div class="color_block" id="color_block">
        <ul>
            <li style="BACKGROUND:#ffffff" onClick="javascript:setcolor('#ffffff');"></li>
            <li style="BACKGROUND:#e5e4e4" onClick="javascript:setcolor('#e5e4e4');"></li>
            <li style="BACKGROUND:#d9d8d8" onClick="javascript:setcolor('#d9d8d8');"></li>
            <li style="BACKGROUND:#c0bdbd" onClick="javascript:setcolor('#c0bdbd');"></li>
            <li style="BACKGROUND:#a7a4a4" onClick="javascript:setcolor('#a7a4a4');"></li>
            <li style="BACKGROUND:#8e8a8b" onClick="javascript:setcolor('#8e8a8b');"></li>
            <li style="BACKGROUND:#827e7f" onClick="javascript:setcolor('#827e7f');"></li>
            <li style="BACKGROUND:#767173" onClick="javascript:setcolor('#767173');"></li>
            <li style="BACKGROUND:#5c585a" onClick="javascript:setcolor('#5c585a');"></li>
            <li style="BACKGROUND:#000000" onClick="javascript:setcolor('#000000');"></li>
            
            <li style="BACKGROUND:#fefcdf" onClick="javascript:setcolor('#fefcdf');"></li>
            <li style="BACKGROUND:#fef4c4" onClick="javascript:setcolor('#fef4c4');"></li>
            <li style="BACKGROUND:#feed9b" onClick="javascript:setcolor('#feed9b');"></li>
            <li style="BACKGROUND:#fee573" onClick="javascript:setcolor('#fee573');"></li>
            <li style="BACKGROUND:#ffed43" onClick="javascript:setcolor('#ffed43');"></li>
            <li style="BACKGROUND:#f6cc0b" onClick="javascript:setcolor('#f6cc0b');"></li>
            <li style="BACKGROUND:#e0b800" onClick="javascript:setcolor('#e0b800');"></li>
            <li style="BACKGROUND:#c9a601" onClick="javascript:setcolor('#c9a601');"></li>
            <li style="BACKGROUND:#ad8e00" onClick="javascript:setcolor('#ad8e00');"></li>
            <li style="BACKGROUND:#8c7301" onClick="javascript:setcolor('#8c7301');"></li>

			<li style="BACKGROUND:#ffded3" onClick="javascript:setcolor('#ffded3');"></li>
            <li style="BACKGROUND:#ffc4b0" onClick="javascript:setcolor('#ffc4b0');"></li>
            <li style="BACKGROUND:#ff9d7d" onClick="javascript:setcolor('#ff9d7d');"></li>
            <li style="BACKGROUND:#ff7a4e" onClick="javascript:setcolor('#ff7a4e');"></li>
            <li style="BACKGROUND:#ff6600" onClick="javascript:setcolor('#ff6600');"></li>
            <li style="BACKGROUND:#e95d00" onClick="javascript:setcolor('#e95d00');"></li>
            <li style="BACKGROUND:#d15502" onClick="javascript:setcolor('#d15502');"></li>
            <li style="BACKGROUND:#ba4b01" onClick="javascript:setcolor('#ba4b01');"></li>
            <li style="BACKGROUND:#a44201" onClick="javascript:setcolor('#a44201');"></li>
            <li style="BACKGROUND:#8d3901" onClick="javascript:setcolor('#8d3901');"></li>
            
            <li style="BACKGROUND:#ffd2d0" onClick="javascript:setcolor('#ffd2d0');"></li>
            <li style="BACKGROUND:#ffbab7" onClick="javascript:setcolor('#ffbab7');"></li>
            <li style="BACKGROUND:#fe9a95" onClick="javascript:setcolor('#fe9a95');"></li>
            <li style="BACKGROUND:#ff7a73" onClick="javascript:setcolor('#ff7a73');"></li>
            <li style="BACKGROUND:#ff483f" onClick="javascript:setcolor('#ff483f');"></li>
            <li style="BACKGROUND:#fe2419" onClick="javascript:setcolor('#fe2419');"></li>
            <li style="BACKGROUND:#f10b00" onClick="javascript:setcolor('#f10b00');"></li>
            <li style="BACKGROUND:#d40a00" onClick="javascript:setcolor('#d40a00');"></li>
            <li style="BACKGROUND:#940000" onClick="javascript:setcolor('#940000');"></li>
            <li style="BACKGROUND:#6d201b" onClick="javascript:setcolor('#6d201b');"></li>
            
 			<li style="BACKGROUND:#ffdaed" onClick="javascript:setcolor('#ffdaed');"></li>
            <li style="BACKGROUND:#ffb7dc" onClick="javascript:setcolor('#ffb7dc');"></li>
            <li style="BACKGROUND:#ffa1d1" onClick="javascript:setcolor('#ffa1d1');"></li>
            <li style="BACKGROUND:#ff84c3" onClick="javascript:setcolor('#ff84c3');"></li>
            <li style="BACKGROUND:#ff57ac" onClick="javascript:setcolor('#ff57ac');"></li>
            <li style="BACKGROUND:#fd1289" onClick="javascript:setcolor('#fd1289');"></li>
            <li style="BACKGROUND:#ec0078" onClick="javascript:setcolor('#ec0078');"></li>
            <li style="BACKGROUND:#d6006d" onClick="javascript:setcolor('#d6006d');"></li>
            <li style="BACKGROUND:#bb005f" onClick="javascript:setcolor('#bb005f');"></li>
            <li style="BACKGROUND:#9b014f" onClick="javascript:setcolor('#9b014f');"></li>
            
            <li style="BACKGROUND:#fcd6fe" onClick="javascript:setcolor('#fcd6fe');"></li>
            <li style="BACKGROUND:#fbbcff" onClick="javascript:setcolor('#fbbcff');"></li>
            <li style="BACKGROUND:#f9a1fe" onClick="javascript:setcolor('#f9a1fe');"></li>
            <li style="BACKGROUND:#f784fe" onClick="javascript:setcolor('#f784fe');"></li>
            <li style="BACKGROUND:#f564fe" onClick="javascript:setcolor('#f564fe');"></li>
            <li style="BACKGROUND:#f546ff" onClick="javascript:setcolor('#f546ff');"></li>
            <li style="BACKGROUND:#f328ff" onClick="javascript:setcolor('#f328ff');"></li>
            <li style="BACKGROUND:#d801e5" onClick="javascript:setcolor('#d801e5');"></li>
            <li style="BACKGROUND:#c001cb" onClick="javascript:setcolor('#c001cb');"></li>
            <li style="BACKGROUND:#8f0197" onClick="javascript:setcolor('#8f0197');"></li>
            
            <li style="BACKGROUND:#e2f0fe" onClick="javascript:setcolor('#e2f0fe');"></li>
            <li style="BACKGROUND:#c7e2fe" onClick="javascript:setcolor('#c7e2fe');"></li>
            <li style="BACKGROUND:#add5fe" onClick="javascript:setcolor('#add5fe');"></li>
            <li style="BACKGROUND:#92c7fe" onClick="javascript:setcolor('#92c7fe');"></li>
            <li style="BACKGROUND:#6eb5ff" onClick="javascript:setcolor('#6eb5ff');"></li>
            <li style="BACKGROUND:#48a2ff" onClick="javascript:setcolor('#48a2ff');"></li>
            <li style="BACKGROUND:#2690fe" onClick="javascript:setcolor('#2690fe');"></li>
            <li style="BACKGROUND:#0162f4" onClick="javascript:setcolor('#0162f4');"></li>
            <li style="BACKGROUND:#013add" onClick="javascript:setcolor('#013add');"></li>
            <li style="BACKGROUND:#0021b0" onClick="javascript:setcolor('#0021b0');"></li>
            
            <li style="BACKGROUND:#d3fdff" onClick="javascript:setcolor('#d3fdff');"></li>
            <li style="BACKGROUND:#acfafd" onClick="javascript:setcolor('#acfafd');"></li>
            <li style="BACKGROUND:#7cfaff" onClick="javascript:setcolor('#7cfaff');"></li>
            <li style="BACKGROUND:#4af7fe" onClick="javascript:setcolor('#4af7fe');"></li>
            <li style="BACKGROUND:#1de6fe" onClick="javascript:setcolor('#1de6fe');"></li>
            <li style="BACKGROUND:#01deff" onClick="javascript:setcolor('#01deff');"></li>
            <li style="BACKGROUND:#00cdec" onClick="javascript:setcolor('#00cdec');"></li>
            <li style="BACKGROUND:#01b6de" onClick="javascript:setcolor('#01b6de');"></li>
            <li style="BACKGROUND:#00a0c2" onClick="javascript:setcolor('#00a0c2');"></li>
            <li style="BACKGROUND:#0084a0" onClick="javascript:setcolor('#0084a0');"></li>
            
            <li style="BACKGROUND:#edffcf" onClick="javascript:setcolor('#edffcf');"></li>
            <li style="BACKGROUND:#dffeaa" onClick="javascript:setcolor('#dffeaa');"></li>
            <li style="BACKGROUND:#d1fd88" onClick="javascript:setcolor('#d1fd88');"></li>
            <li style="BACKGROUND:#befa5a" onClick="javascript:setcolor('#befa5a');"></li>
            <li style="BACKGROUND:#a8f32a" onClick="javascript:setcolor('#a8f32a');"></li>
            <li style="BACKGROUND:#8fd80a" onClick="javascript:setcolor('#8fd80a');"></li>
            <li style="BACKGROUND:#79c101" onClick="javascript:setcolor('#79c101');"></li>
            <li style="BACKGROUND:#3fa701" onClick="javascript:setcolor('#3fa701');"></li>
            <li style="BACKGROUND:#307f00" onClick="javascript:setcolor('#307f00');"></li>
            <li style="BACKGROUND:#156200" onClick="javascript:setcolor('#156200');"></li>
            
            <li style="BACKGROUND:#d4c89f" onClick="javascript:setcolor('#d4c89f');"></li>
            <li style="BACKGROUND:#daad88" onClick="javascript:setcolor('#daad88');"></li>
            <li style="BACKGROUND:#c49578" onClick="javascript:setcolor('#c49578');"></li>
            <li style="BACKGROUND:#c2877e" onClick="javascript:setcolor('#c2877e');"></li>
            <li style="BACKGROUND:#ac8295" onClick="javascript:setcolor('#ac8295');"></li>
            <li style="BACKGROUND:#c0a5c4" onClick="javascript:setcolor('#c0a5c4');"></li>
            <li style="BACKGROUND:#969ac2" onClick="javascript:setcolor('#969ac2');"></li>
            <li style="BACKGROUND:#92b7d7" onClick="javascript:setcolor('#92b7d7');"></li>
            <li style="BACKGROUND:#80adaf" onClick="javascript:setcolor('#80adaf');"></li>
            <li style="BACKGROUND:#9ca53b" onClick="javascript:setcolor('#9ca53b');"></li>
            <li class="last">
            	<div class="font_style">
                	<ul>
                    	<li onClick="javascript:setbold();"><b>B</b></li>
                        <li onClick="javascript:setem();"><b><em>I</em></b></li>
                        <li onClick="javascript:setu();"><b><u>U</u></b></li>
                       
                        <li onClick="javascript:setauto();"><b>Auto</b></li>
                        <li onClick="javascript:closesub();" class="close"><b>Close</b></li>
                    </ul>
                </div>
            </li>
        </ul>
    </div>
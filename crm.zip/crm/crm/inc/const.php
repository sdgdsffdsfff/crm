<?php
//系统参数
$sitename = "CRM";
$keywords = "asdasd";
$description = "asdasd";

$installdir = "";
$templatedir = "template/";
$databasePrefix = "crm_";
$indexname = "crm";
$indextemplate = 'index.html';
$httpurl = "http://127.0.0.1/crm";
$defaultext = 'html';
$sitepathsplit = ' > ';
$titlepathsplit = ' - ';
$rewriteext = '.html';
$author = "Admin";
$source = "本站";
$site_beian = "123456";
$manager_email = "info@pifasoft.com";
$sysversion = "V2.0.101108_UTF8";
$issetup = "0";
include 'conn.php'; 

?>